const analyzeBtn = document.getElementById("analyzeBtn");
const speakBtn = document.getElementById("speakBtn");
const userInput = document.getElementById("userInput");
const output = document.getElementById("output");
const mode = document.getElementById("mode");

// Basic word-based emotion detection
function detectEmotion(text) {
  text = text.toLowerCase();

  const happyWords = ["happy", "great", "love", "awesome", "amazing"];
  const sadWords = ["sad", "unhappy", "bad", "cry", "hurt","lost"];
  const angryWords = ["angry", "mad", "furious", "hate"];
  const questionWords = ["what", "why", "how", "when", "where", "who"];

  if (happyWords.some(w => text.includes(w))) return "happy";
  if (sadWords.some(w => text.includes(w))) return "sad";
  if (angryWords.some(w => text.includes(w))) return "angry";
  if (questionWords.some(w => text.includes(w))) return "neutral-question";

  return "neutral";
}

// Generate response based on emotion + mode
function generateResponse(text, mode) {
  const emotion = detectEmotion(text);

const responses = {
  kid: {
    happy: "Yippee! 😄 That’s awesome!",
    sad: "Oh no! 😢 I’m giving you a big virtual hug!",
    angry: "Uh oh! 😠 Let’s count to three and blow the anger away like bubbles... 🎈 Ready? 1...2...3! 😌",
    "neutral-question": "Ooh, that’s a super cool question! 🤔 Let’s figure it out together!",
    neutral: "Hehe, that sounds nice! 🌈 Thanks for sharing that with me!"
  },
  teen: {
    happy: "That’s awesome! 😄 Sounds like something really good happened.",
    sad: "Hey, that sounds rough. 😔 Want to vent a bit?",
    angry: "Totally get it — sometimes stuff just gets on your nerves. 😤 Try to chill a bit if you can.",
    "neutral-question": "Interesting question — you’re really thinking things through. 🤓",
    neutral: "Cool. Sounds pretty normal. 👍"
  },
  adult: {
  happy: "That’s wonderful to hear! 😊 It sounds like something went really well for you.I’m so happy for you! Wanna tell me more?",
  sad: "I can sense some sadness there. 💙 Remember, it’s okay to feel down — be kind to yourself.",
  angry: "I understand that frustration. 😤 Maybe taking a moment before responding could help clear your thoughts.",
  "neutral-question": "That’s a thoughtful question — curious and open-minded. 🤔",
  neutral: "That sounds clear and steady — like you’re just sharing information calmly. 👍"
  }
};

  return responses[mode][emotion];
}

analyzeBtn.addEventListener("click", () => {
  const text = userInput.value.trim();
  if (!text) {
    output.textContent = "Please enter a message first.";
    return;
  }

  const response = generateResponse(text, mode.value);
  output.textContent = response;
});

speakBtn.addEventListener("click", () => {
  const text = output.textContent;
  if (!text) return;
  const utterance = new SpeechSynthesisUtterance(text);
  speechSynthesis.speak(utterance);
});
